import{v as o}from"./2.mZIydTfq.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.C_-DfdnD.js.map
