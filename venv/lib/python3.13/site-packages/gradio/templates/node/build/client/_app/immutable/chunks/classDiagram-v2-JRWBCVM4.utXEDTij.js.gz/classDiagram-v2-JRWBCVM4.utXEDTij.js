import{c as r,C as s,a as e,s as t}from"./chunk-5V4FS25O.R4rcW6Bw.js";import{_ as l}from"./mermaid.core.uZuTP_Vc.js";var d={parser:r,get db(){return new s},renderer:e,styles:t,init:l(a=>{a.class||(a.class={}),a.class.arrowMarkerAbsolute=a.arrowMarkerAbsolute},"init")};export{d as diagram};
//# sourceMappingURL=classDiagram-v2-JRWBCVM4.utXEDTij.js.map
