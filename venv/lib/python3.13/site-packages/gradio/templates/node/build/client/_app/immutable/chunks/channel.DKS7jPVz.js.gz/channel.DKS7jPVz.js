import{U as a,C as n}from"./mermaid.core.uZuTP_Vc.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.DKS7jPVz.js.map
