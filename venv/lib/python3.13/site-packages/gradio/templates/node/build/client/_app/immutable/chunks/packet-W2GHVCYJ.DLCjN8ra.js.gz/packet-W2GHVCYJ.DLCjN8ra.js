import{P as c,a as r}from"./mermaid-parser.core.DwuJc0jl.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-W2GHVCYJ.DLCjN8ra.js.map
