import{s as t}from"../chunks/client.DuJBNQo6.js";export{t as start};
//# sourceMappingURL=start.Bu0cnyld.js.map
