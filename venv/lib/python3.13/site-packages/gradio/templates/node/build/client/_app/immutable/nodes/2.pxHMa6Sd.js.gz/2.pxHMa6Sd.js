import{Z as e,_ as n}from"../chunks/2.mZIydTfq.js";export{e as component,n as universal};
//# sourceMappingURL=2.pxHMa6Sd.js.map
